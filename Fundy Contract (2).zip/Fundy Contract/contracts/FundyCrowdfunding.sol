// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@openzeppelin/contracts/security/ReentrancyGuard.sol";
import "./FundyToken.sol";
import "./FundyNFT.sol";

/**
 * @title FundyCrowdfunding
 *
 * Key fixes vs original:
 *  1. Separate tracking of actual ETH raised vs FDY-equivalent raised per campaign,
 *     so withdrawal and refunds never draw from the wrong pool.
 *  2. FDY donors receive an FDY refund (re-mint) instead of ETH on refund/cancel.
 *  3. cancelCampaign no longer loops over donors — it only flips the flag.
 *     Each donor claims their own refund via claimRefund(), avoiding gas exhaustion.
 *  4. ReentrancyGuard on all external state-changing functions that transfer value.
 *  5. mintForDonation now returns the minted amount, eliminating the redundant
 *     local calculation in donate().
 *  6. NFT_THRESHOLD_ETH is now a constructor-settable parameter (owner can update)
 *     to handle ETH/MYR rate changes without redeployment.
 */
contract FundyCrowdfunding is ReentrancyGuard {

    // ── Structs ────────────────────────────────────────────────
    struct Campaign {
        string  supabaseId;
        address organizer;
        uint256 goalAmount;           // wei
        uint256 deadline;             // unix timestamp
        uint256 totalRaisedEth;       // actual ETH held in contract (wei)
        uint256 totalRaisedFdy;       // FDY-equivalent credited (wei units) — NOT held as ETH
        bool    withdrawn;
        bool    cancelled;
        // Extra token reward config
        bool    hasExtraToken;
        uint256 extraTokenAmount;     // FDY (1e18 units) per qualifying donation
        uint256 extraTokenMinDonate;  // minimum ETH (wei) to qualify for extra FDY
        // NFT reward config
        bool    hasNft;
    }

    // ── State ──────────────────────────────────────────────────
    FundyToken public immutable token;
    FundyNFT   public immutable nft;
    address    public owner;

    /**
     * @notice Minimum donation (in wei) to qualify for an NFT reward.
     *         Defaults to 0.5 ETH. Owner can update via setNftThreshold().
     */
    uint256 public nftThresholdEth;

    uint256 public campaignCount;

    mapping(uint256 => Campaign)                    public campaigns;

    // ETH donations per donor per campaign (for ETH refunds)
    mapping(uint256 => mapping(address => uint256)) public ethDonations;
    // FDY-equivalent donations per donor per campaign (for FDY refunds)
    mapping(uint256 => mapping(address => uint256)) public fdyDonations;

    mapping(uint256 => address[])                   public donors;
    mapping(uint256 => mapping(address => bool))    public isDonor;
    mapping(uint256 => mapping(address => bool))    public hasNftForCampaign;

    // ── Events ─────────────────────────────────────────────────
    event CampaignCreated(uint256 indexed campaignId, string supabaseId, address organizer, uint256 goal, uint256 deadline);
    event DonationReceived(uint256 indexed campaignId, address indexed donor, uint256 ethAmount, uint256 fdyMinted);
    event ExtraFdyAwarded(uint256 indexed campaignId, address indexed donor, uint256 fdyAmount);
    event NftAwarded(uint256 indexed campaignId, address indexed donor, uint256 tokenId);
    event FdyDonation(uint256 indexed campaignId, address indexed donor, uint256 fdyBurned, uint256 ethEquivalent);
    event FundsWithdrawn(uint256 indexed campaignId, address organizer, uint256 ethAmount, uint256 fdyEquivalent);
    event EthRefundIssued(uint256 indexed campaignId, address indexed donor, uint256 amount);
    event FdyRefundIssued(uint256 indexed campaignId, address indexed donor, uint256 fdyAmount);
    event CampaignCancelled(uint256 indexed campaignId);
    event NftThresholdUpdated(uint256 newThreshold);

    // ── Modifiers ──────────────────────────────────────────────
    modifier onlyOwner() { require(msg.sender == owner, "Not owner"); _; }
    modifier exists(uint256 id) { require(id > 0 && id <= campaignCount, "Campaign does not exist"); _; }
    modifier active(uint256 id) {
        Campaign storage c = campaigns[id];
        require(!c.cancelled, "Campaign cancelled");
        require(block.timestamp < c.deadline, "Campaign deadline passed");
        _;
    }

    // ── Constructor ────────────────────────────────────────────
    constructor(address _token, address _nft) {
        owner = msg.sender;
        token = FundyToken(_token);
        nft   = FundyNFT(_nft);
        nftThresholdEth = 0.5 ether; // default: ~RM500 at launch rate
        token.transferOwnership(address(this));
        nft.transferOwnership(address(this));
        token.setCrowdfundingContract(address(this));
    }

    // ── Admin ──────────────────────────────────────────────────

    /**
     * @notice Update the minimum ETH-equivalent donation for NFT rewards.
     *         Call this when the ETH/MYR rate shifts significantly.
     */
    function setNftThreshold(uint256 newThreshold) external onlyOwner {
        require(newThreshold > 0, "Threshold must be > 0");
        nftThresholdEth = newThreshold;
        emit NftThresholdUpdated(newThreshold);
    }

    function transferOwnership(address newOwner) external onlyOwner {
        require(newOwner != address(0), "Zero address");
        owner = newOwner;
    }

    // ── Campaign creation ──────────────────────────────────────

    function createCampaign(
        string  calldata supabaseId,
        uint256 goalWei,
        uint256 deadline,
        string  calldata nftUri,
        uint256 extraTokenAmount,
        uint256 extraTokenMinDonate
    ) external returns (uint256 campaignId) {
        require(deadline > block.timestamp, "Deadline must be future");
        require(goalWei > 0, "Goal must be > 0");

        campaignCount++;
        campaignId = campaignCount;

        bool hasNftReward = bytes(nftUri).length > 0;
        if (hasNftReward) {
            nft.setCampaignNftUri(campaignId, nftUri);
        }

        campaigns[campaignId] = Campaign({
            supabaseId:          supabaseId,
            organizer:           msg.sender,
            goalAmount:          goalWei,
            deadline:            deadline,
            totalRaisedEth:      0,
            totalRaisedFdy:      0,
            withdrawn:           false,
            cancelled:           false,
            hasExtraToken:       extraTokenAmount > 0,
            extraTokenAmount:    extraTokenAmount,
            extraTokenMinDonate: extraTokenMinDonate,
            hasNft:              hasNftReward
        });

        emit CampaignCreated(campaignId, supabaseId, msg.sender, goalWei, deadline);
    }

    // ── ETH Donation ───────────────────────────────────────────

    /**
     * @notice Donate ETH to a campaign.
     *
     *  1. ETH is held in this contract, tracked per campaign.
     *  2. Base FDY reward minted to donor (1 ETH = 100 FDY).
     *  3. If donation >= extraTokenMinDonate AND organizer has approved FDY:
     *     extra FDY transferred from organizer to donor.
     *  4. If donation >= nftThresholdEth AND campaign has NFT:
     *     unique NFT minted to donor (once per donor per campaign).
     */
    function donate(uint256 campaignId)
        external payable
        exists(campaignId) active(campaignId)
        nonReentrant
    {
        require(msg.value > 0, "Must send ETH");
        Campaign storage c = campaigns[campaignId];
        require(msg.sender != c.organizer, "Organizer cannot donate to own campaign");

        // Record ETH donation
        _recordEthDonation(campaignId, msg.sender, msg.value);

        // Mint base FDY reward; mintForDonation returns the exact amount
        uint256 fdyMinted = token.mintForDonation(msg.sender, msg.value);
        emit DonationReceived(campaignId, msg.sender, msg.value, fdyMinted);

        // Extra FDY from organizer (if configured)
        if (c.hasExtraToken && msg.value >= c.extraTokenMinDonate) {
            _tryAwardExtraFdy(campaignId, msg.sender, c);
        }

        // NFT reward
        if (c.hasNft && msg.value >= nftThresholdEth && !hasNftForCampaign[campaignId][msg.sender]) {
            hasNftForCampaign[campaignId][msg.sender] = true;
            uint256 tokenId = nft.mintReward(msg.sender, campaignId);
            emit NftAwarded(campaignId, msg.sender, tokenId);
        }
    }

    // ── FDY Donation ───────────────────────────────────────────

    /**
     * @notice Donate using FDY tokens.
     *         FDY is burned; ETH-equivalent is credited to the campaign goal.
     *         On refund, the donor receives freshly minted FDY (not ETH).
     *
     * Caller must first approve this contract:
     *   token.approve(address(crowdfunding), fdyAmount)
     *
     * Note: FDY donations do NOT earn extra FDY rewards.
     *       NFT reward still applies if ETH-equivalent >= nftThresholdEth.
     */
    function donateWithFdy(uint256 campaignId, uint256 fdyAmount)
        external
        exists(campaignId) active(campaignId)
        nonReentrant
    {
        require(fdyAmount > 0, "Must send FDY");
        Campaign storage c = campaigns[campaignId];
        require(msg.sender != c.organizer, "Organizer cannot donate to own campaign");

        uint256 ethEquivalent = token.fdyToEth(fdyAmount);
        require(ethEquivalent > 0, "FDY amount too small");

        // Burn FDY from donor
        token.burnForDonation(msg.sender, fdyAmount);

        // Record as FDY donation (separate from ETH donations)
        _recordFdyDonation(campaignId, msg.sender, fdyAmount, ethEquivalent);
        emit FdyDonation(campaignId, msg.sender, fdyAmount, ethEquivalent);

        // NFT reward
        if (c.hasNft && ethEquivalent >= nftThresholdEth && !hasNftForCampaign[campaignId][msg.sender]) {
            hasNftForCampaign[campaignId][msg.sender] = true;
            uint256 tokenId = nft.mintReward(msg.sender, campaignId);
            emit NftAwarded(campaignId, msg.sender, tokenId);
        }
    }

    // ── Internal helpers ───────────────────────────────────────

    function _recordEthDonation(uint256 campaignId, address donor, uint256 amount) internal {
        if (!isDonor[campaignId][donor]) {
            donors[campaignId].push(donor);
            isDonor[campaignId][donor] = true;
        }
        ethDonations[campaignId][donor] += amount;
        campaigns[campaignId].totalRaisedEth += amount;
    }

    function _recordFdyDonation(uint256 campaignId, address donor, uint256 fdyAmount, uint256 ethEquivalent) internal {
        if (!isDonor[campaignId][donor]) {
            donors[campaignId].push(donor);
            isDonor[campaignId][donor] = true;
        }
        fdyDonations[campaignId][donor] += fdyAmount;
        campaigns[campaignId].totalRaisedFdy += ethEquivalent;
    }

    function _tryAwardExtraFdy(uint256 campaignId, address donor, Campaign storage c) internal {
        try token.transferFrom(c.organizer, donor, c.extraTokenAmount) {
            emit ExtraFdyAwarded(campaignId, donor, c.extraTokenAmount);
        } catch {
            // Organizer out of FDY or approval revoked — skip silently
        }
    }

    // ── Withdrawal ─────────────────────────────────────────────

    /**
     * @notice Organizer withdraws funds once the goal is reached.
     *         Only actual ETH held in the contract is sent.
     *         FDY-equivalent is acknowledged in the event for accounting.
     */
    function withdraw(uint256 campaignId) external exists(campaignId) nonReentrant {
        Campaign storage c = campaigns[campaignId];
        require(msg.sender == c.organizer, "Not organizer");
        require(!c.cancelled, "Campaign cancelled");
        require(!c.withdrawn, "Already withdrawn");
        require(
            c.totalRaisedEth + c.totalRaisedFdy >= c.goalAmount,
            "Goal not reached"
        );

        c.withdrawn = true;

        uint256 ethToSend = c.totalRaisedEth; // only actual ETH this campaign holds
        if (ethToSend > 0) {
            (bool ok,) = payable(c.organizer).call{value: ethToSend}("");
            require(ok, "Transfer failed");
        }

        emit FundsWithdrawn(campaignId, c.organizer, ethToSend, c.totalRaisedFdy);
    }

    // ── Refund ─────────────────────────────────────────────────

    /**
     * @notice Claim a refund when a campaign fails or is cancelled.
     *         - ETH donors receive ETH back.
     *         - FDY donors receive freshly minted FDY back (their original FDY was burned).
     */
    function claimRefund(uint256 campaignId) external exists(campaignId) nonReentrant {
        Campaign storage c = campaigns[campaignId];
        require(!c.withdrawn, "Funds already withdrawn");
        require(
            c.cancelled || (block.timestamp >= c.deadline && c.totalRaisedEth + c.totalRaisedFdy < c.goalAmount),
            "Refund not available"
        );

        // ETH refund
        uint256 ethAmount = ethDonations[campaignId][msg.sender];
        if (ethAmount > 0) {
            ethDonations[campaignId][msg.sender] = 0;
            (bool ok,) = payable(msg.sender).call{value: ethAmount}("");
            require(ok, "ETH refund failed");
            emit EthRefundIssued(campaignId, msg.sender, ethAmount);
        }

        // FDY refund (re-mint the burned tokens)
        uint256 fdyAmount = fdyDonations[campaignId][msg.sender];
        if (fdyAmount > 0) {
            fdyDonations[campaignId][msg.sender] = 0;
            // Re-mint — use a direct amount mint (not tied to ETH conversion)
            token.mintForDonation(msg.sender, (fdyAmount * 1 ether) / (token.TOKENS_PER_ETH() * 10 ** 18));
            emit FdyRefundIssued(campaignId, msg.sender, fdyAmount);
        }

        require(ethAmount > 0 || fdyAmount > 0, "Nothing to refund");
    }

    // ── Cancel ─────────────────────────────────────────────────

    /**
     * @notice Cancel a campaign. Sets the cancelled flag only.
     *         Donors must call claimRefund() individually to avoid gas exhaustion
     *         from looping over an unbounded donor list.
     */
    function cancelCampaign(uint256 campaignId) external exists(campaignId) {
        Campaign storage c = campaigns[campaignId];
        require(msg.sender == owner || msg.sender == c.organizer, "Not authorized");
        require(!c.cancelled, "Already cancelled");
        require(!c.withdrawn, "Already withdrawn");

        c.cancelled = true;
        emit CampaignCancelled(campaignId);
        // Donors call claimRefund() themselves.
    }

    // ── Views ──────────────────────────────────────────────────

    function getCampaign(uint256 id) external view exists(id) returns (Campaign memory) {
        return campaigns[id];
    }

    /// @notice Total effective raised (ETH + FDY-equivalent) for goal comparison.
    function totalRaised(uint256 id) external view exists(id) returns (uint256) {
        return campaigns[id].totalRaisedEth + campaigns[id].totalRaisedFdy;
    }

    function getEthDonation(uint256 id, address donor) external view returns (uint256) {
        return ethDonations[id][donor];
    }

    function getFdyDonation(uint256 id, address donor) external view returns (uint256) {
        return fdyDonations[id][donor];
    }

    function getDonors(uint256 id) external view returns (address[] memory) {
        return donors[id];
    }

    function isGoalReached(uint256 id) external view exists(id) returns (bool) {
        Campaign storage c = campaigns[id];
        return c.totalRaisedEth + c.totalRaisedFdy >= c.goalAmount;
    }

    function isRefundable(uint256 id) external view exists(id) returns (bool) {
        Campaign storage c = campaigns[id];
        return !c.withdrawn && (
            c.cancelled ||
            (block.timestamp >= c.deadline && c.totalRaisedEth + c.totalRaisedFdy < c.goalAmount)
        );
    }

    receive() external payable {}
}
